/* Generated automatically by the program `build/gcov-iov'
   from `4.6.x-google (4 6) and prerelease (p)'.  */

#define GCOV_VERSION ((gcov_unsigned_t)0x34303670)  /* 406p */
