#include <iostream>

int main(void)
{
    time_t  now = 0;

    std::cout << "Hello ";
    std::cout << 1.0;
    std::cout << now;
    std::cout << " World" << std::endl;
}
