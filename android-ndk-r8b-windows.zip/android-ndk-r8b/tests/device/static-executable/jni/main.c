#include <stdio.h>

int main(void)
{
  printf("Hello static world!\n");
  return 0;
}
